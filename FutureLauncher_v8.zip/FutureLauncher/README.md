# Future Launcher v8
Build: suba tudo pro GitHub -> Actions -> "Build APK" -> baixe FutureLauncher-APK. Desinstale a versao anterior antes.
Home: 3 layouts (Minimo, Classico, Hub) na engrenagem. Hub = atalhos, respostas rapidas (compartilha pro WhatsApp), contador de clientes pagantes, foco 25 min.
Gaveta: abas (Todos, Favoritos, categorias), grade/lista, barra A-Z lateral, Enter abre o 1o resultado. Segure um app: dock, favorito, info, desinstalar.
v7: assistente orb vivo, atalhos de apps, Instagram story\/reels\/post, timer 33 (digite: timer 33).
v8: bolinha de tema na home (leque de cores, 8 temas), gaveta de apps em estilo terminal hacker (cor segue o tema), microfone abre o assistente padrao do sistema (Gemini/Assistant) via ACTION_ASSIST.
