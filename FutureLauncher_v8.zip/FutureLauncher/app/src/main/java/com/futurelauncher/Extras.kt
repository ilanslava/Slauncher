package com.futurelauncher

import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Easing com leve overshoot (a bolinha "pula" um pouco além e volta). */
private val BackOut = Easing { t -> val u = t - 1f; u * u * (2.70158f * u + 1.70158f) + 1f }

/** A bolinha do topo: mostra o gradiente do tema atual. Toque abre/fecha o leque de cores. */
@Composable
fun ThemeOrb(theme: Theme, open: Boolean, onToggle: () -> Unit, onCenter: (Offset) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val rot by animateFloatAsState(if (open) 135f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "orbRot")
    Box(
        Modifier.padding(6.dp).size(34.dp)
            .onGloballyPositioned { val p = it.positionInRoot(); onCenter(Offset(p.x + it.size.width / 2f, p.y + it.size.height / 2f)) }
            .graphicsLayer { rotationZ = rot }
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(theme.a, theme.b)))
            .border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape)
            .clickable { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onToggle() }
    )
}

/** Leque de bolinhas coloridas que abre a partir da bolinha. Tocar numa cor aplica o tema. */
@Composable
fun ThemeFan(open: Boolean, center: Offset, current: Int, onPick: (Int) -> Unit, onClose: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(open) { if (open) show = true else { delay(450); show = false } }
    if (!show) return
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(open) { go = open }
    val src = remember { MutableInteractionSource() }
    val d = 30.dp
    val r = 140.dp
    Box(
        Modifier.fillMaxSize()
            .then(if (open) Modifier.clickable(interactionSource = src, indication = null) { onClose() } else Modifier)
    ) {
        Themes.forEachIndexed { i, th ->
            val ang = Math.toRadians(95.0 + 95.0 * i / (Themes.size - 1).coerceAtLeast(1))
            val pr by animateFloatAsState(if (go) 1f else 0f, tween(340, delayMillis = if (go) i * 30 else 0, easing = BackOut), label = "dot")
            Box(
                Modifier
                    .offset {
                        IntOffset(
                            (center.x + cos(ang).toFloat() * r.toPx() * pr - d.toPx() / 2f).roundToInt(),
                            (center.y + sin(ang).toFloat() * r.toPx() * pr - d.toPx() / 2f).roundToInt()
                        )
                    }
                    .size(d)
                    .graphicsLayer { alpha = pr.coerceIn(0f, 1f); scaleX = pr.coerceAtLeast(0f); scaleY = pr.coerceAtLeast(0f) }
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(th.a, th.b)))
                    .border(if (i == current) 3.dp else 1.dp, Color.White.copy(alpha = if (i == current) 1f else 0.4f), CircleShape)
                    .clickable(enabled = open) { onPick(i) }
            )
        }
    }
}
