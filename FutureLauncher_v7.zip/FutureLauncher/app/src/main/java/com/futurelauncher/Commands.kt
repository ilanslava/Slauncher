package com.futurelauncher

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.speech.RecognizerIntent
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Calendar
import java.util.Locale

/** Texto no idioma do sistema: português se o sistema estiver em português, senão inglês. */
fun tr(pt: String, en: String): String = if (Locale.getDefault().language == "pt") pt else en

private var torchOn = false

private class Calc(val s: String) {
    var i = 0
    fun p() = if (i < s.length) s[i] else ' '
    fun expr(): Double { var v = term(); while (p() == '+' || p() == '-') { val o = p(); i++; val t = term(); v = if (o == '+') v + t else v - t }; return v }
    fun term(): Double { var v = fac(); while (p() == '*' || p() == '/') { val o = p(); i++; val t = fac(); v = if (o == '*') v * t else v / t }; return v }
    fun fac(): Double {
        if (p() == '-') { i++; return -fac() }
        if (p() == '(') { i++; val v = expr(); if (p() == ')') i++; return v }
        val st = i
        while (p().isDigit() || p() == '.') i++
        return s.substring(st, i).toDouble()
    }
}

private class T(val h: Int, val m: Int, val r: IntRange)

private fun parseTime(l: String): T? {
    val mt = Regex("(\\d{1,2})(?:[:h](\\d{2}))?(?:\\s*(am|pm|h|horas?|hours?)\\b)?").find(l) ?: return null
    var h = mt.groupValues[1].toInt()
    val m = mt.groupValues[2].ifEmpty { "0" }.toInt()
    val suf = mt.groupValues[3]
    if (h > 23 || m > 59) return null
    if (suf == "pm" && h < 12) h += 12
    if (suf == "am" && h == 12) h = 0
    if (suf.isEmpty() && h < 12 && Regex("tarde|noite|afternoon|evening|night").containsMatchIn(l)) h += 12
    return T(h, m, mt.range)
}

private fun clean(l: String, tm: T?, words: String): String {
    var s = if (tm != null) l.removeRange(tm.r) else l
    s = s.replace(Regex("(?<!\\S)($words)(?!\\S)"), " ").replace(Regex("\\s+"), " ").trim()
    return s.replaceFirstChar { it.uppercase() }
}

private fun torch(ctx: Context, on: Boolean?): String = try {
    val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
    if (id == null) tr("Esse celular não tem lanterna", "This phone has no flashlight") else {
        torchOn = on ?: !torchOn
        cm.setTorchMode(id, torchOn)
        if (torchOn) tr("Lanterna ligada 🔦", "Flashlight on 🔦") else tr("Lanterna desligada", "Flashlight off")
    }
} catch (e: Exception) { tr("Não consegui usar a lanterna", "Couldn't use the flashlight") }

/** Abre o assistente de voz do sistema (Google Assistant / Gemini). */
fun openVoiceAssistant(ctx: Context): String {
    val tries = listOf(
        Intent(Intent.ACTION_VOICE_COMMAND).setPackage("com.google.android.googlequicksearchbox"),
        Intent(Intent.ACTION_VOICE_COMMAND),
        Intent(Intent.ACTION_ASSIST),
        Intent(RecognizerIntent.ACTION_WEB_SEARCH)
    )
    for (i in tries) try { ctx.startActivity(i); return "" } catch (e: Exception) { }
    return tr("Nenhum assistente de voz encontrado", "No voice assistant found")
}

fun runCommand(ctx: Context, raw: String, apps: List<AppInfo>, launch: (AppInfo) -> Unit): String {
    val l = raw.trim().lowercase(Locale.getDefault())
    if (l.isEmpty()) return ""
    fun go(i: Intent): Boolean = try { ctx.startActivity(i); true } catch (e: Exception) { false }
    fun view(url: String) = go(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    fun enc(s: String) = Uri.encode(s)

    if (l == "ajuda" || l == "help" || l == "?") return tr(
        "Experimente: alarme 7:30 acordar • timer 10 min • lanterna • 12*8 • abrir instagram • zap 11999999999 oi • youtube lofi • rota casa • lembrete dentista amanhã 15h • gemini <pergunta> • wifi • bateria",
        "Try: alarm 7:30 am wake up • timer 10 min • flashlight • 12*8 • open instagram • zap 15551234567 hi • youtube lofi • route home • remind dentist tomorrow 3pm • gemini <question> • wifi • battery"
    )

    if (Regex("^[0-9+\\-*/x×÷().,\\s]+$").matches(l) && l.any { it in "+-*/x×÷" }) {
        return runCatching {
            val v = Calc(l.replace("x", "*").replace("×", "*").replace("÷", "/").replace(",", ".").replace(" ", "")).expr()
            "= " + (if (v % 1.0 == 0.0 && kotlin.math.abs(v) < 1e15) v.toLong().toString() else String.format(Locale.getDefault(), "%.6f", v).trimEnd('0').trimEnd('.', ','))
        }.getOrDefault(tr("Conta inválida", "Invalid expression"))
    }

    if (Regex("lanterna|flashlight|torch").containsMatchIn(l)) {
        return torch(ctx, when {
            Regex("desligar|desliga|apagar|apaga|\\boff\\b").containsMatchIn(l) -> false
            Regex("ligar|liga|acender|acende|\\bon\\b").containsMatchIn(l) -> true
            else -> null
        })
    }

    if (Regex("\\b(alarme|despertador|acordar|acorda|alarm|wake)\\b").containsMatchIn(l)) {
        val tm = parseTime(l) ?: return tr("Qual horário? Ex.: alarme 7:30", "What time? E.g. alarm 7:30 am")
        val label = clean(l, tm, "alarme|despertador|acordar|me|acorda|às|as|para|pra|de|da|manhã|tarde|noite|hoje|horas|hora|alarm|set|an|a|at|wake|up|for|am|pm|today|the|afternoon|evening|night")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, tm.h).putExtra(AlarmClock.EXTRA_MINUTES, tm.m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.ifEmpty { tr("Alarme", "Alarm") }).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (go(i)) tr("Alarme criado para ", "Alarm set for ") + "%02d:%02d ⏰ %s".format(tm.h, tm.m, label)
        else tr("Não consegui criar o alarme", "Couldn't set the alarm")
    }

    Regex("\\b(timer|temporizador|cronômetro|cronometro|countdown)\\b.*?(\\d+)\\s*(h|hora|horas|hour|hours|min|mins|minuto|minutos|minute|minutes|seg|segundos|s|sec|secs|seconds)?\\b").find(l)?.let {
        val n = it.groupValues[2].toInt()
        val u = it.groupValues[3].ifEmpty { "min" }
        val secs = when { u.startsWith("h") -> n * 3600; u.startsWith("min") -> n * 60; else -> n }
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (go(i)) tr("Timer iniciado ⏱ ", "Timer started ⏱ ") + "$n $u" else tr("Não consegui criar o timer", "Couldn't start the timer")
    }

    Regex("^(zap|whatsapp|wpp)\\s+\\+?([\\d\\s()-]{8,})\\s*(.*)$").find(l)?.let {
        val num = it.groupValues[2].filter { c -> c.isDigit() }
        val full = if (Locale.getDefault().language == "pt" && num.length <= 11) "55$num" else num
        view("https://wa.me/$full?text=" + enc(it.groupValues[3]))
        return "WhatsApp 💬"
    }

    Regex("^(ligar|ligue|chamar|telefonar|call|dial|phone)\\D*([\\d()\\s+-]{6,})$").find(l)?.let {
        go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + it.groupValues[2].filter { c -> c.isDigit() || c == '+' })))
        return tr("Abrindo discador 📞", "Opening dialer 📞")
    }

    if (Regex("wi-?fi").containsMatchIn(l)) { go(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Wi-Fi" }
    if (l.contains("bluetooth")) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Bluetooth" }
    if (Regex("bateria|battery").containsMatchIn(l)) {
        val b = (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return tr("Bateria em $b% 🔋", "Battery at $b% 🔋")
    }
    if (Regex("que horas|what time|^hora$|^time$").containsMatchIn(l)) return tr("Agora são ", "It's ") + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
    if (Regex("que dia|what day|date|^data$").containsMatchIn(l)) return LocalDateTime.now().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale.getDefault()))

    Regex("^(lembrar|lembrete|evento|agendar|marcar|remind|reminder|event|schedule)\\b").find(l)?.let {
        val tm = parseTime(l)
        val title = clean(l, tm, "lembrar|lembrete|evento|agendar|marcar|de|às|as|amanhã|hoje|horas|hora|da|manhã|tarde|noite|para|pra|remind|reminder|event|schedule|me|to|at|tomorrow|today|am|pm|for|about")
        val cal = Calendar.getInstance()
        if (Regex("amanhã|tomorrow").containsMatchIn(l)) cal.add(Calendar.DAY_OF_YEAR, 1)
        if (tm != null) { cal.set(Calendar.HOUR_OF_DAY, tm.h); cal.set(Calendar.MINUTE, tm.m) }
        val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.timeInMillis)
        return if (go(i)) tr("Abrindo agenda 📅", "Opening calendar 📅") else tr("Não achei app de agenda", "No calendar app found")
    }

    Regex("^(gemini|pergunta|perguntar|ask)\\s+(.+)$").find(l)?.let {
        val ok = go(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, it.groupValues[2]).setPackage("com.google.android.apps.bard"))
        if (!ok) view("https://www.google.com/search?q=" + enc(it.groupValues[2]))
        return if (ok) "Gemini ✨" else tr("Gemini não encontrado, pesquisando…", "Gemini not found, searching…")
    }
    Regex("^(youtube|yt)\\s+(.+)$").find(l)?.let { view("https://www.youtube.com/results?search_query=" + enc(it.groupValues[2])); return "YouTube ▶" }
    Regex("^(rota|mapa|mapas|ir para|navegar|route|maps?|directions|navigate|go to)\\s+(?:(?:para|to)\\s+)?(.+)$").find(l)?.let { view("geo:0,0?q=" + enc(it.groupValues[2])); return tr("Abrindo mapas 🗺", "Opening maps 🗺") }
    Regex("^(pesquisar|pesquisa|buscar|google|search)\\s+(.+)$").find(l)?.let { view("https://www.google.com/search?q=" + enc(it.groupValues[2])); return tr("Pesquisando…", "Searching…") }

    val name = Regex("^(abrir|abre|abra|iniciar|open|launch|start)\\s+(?:(?:o|a|the)\\s+)?(.+)$").find(l)?.groupValues?.get(2) ?: l
    val app = apps.firstOrNull { it.label.lowercase() == name }
        ?: apps.firstOrNull { it.label.lowercase().startsWith(name) }
        ?: apps.firstOrNull { it.label.lowercase().contains(name) }
    if (app != null) { launch(app); return tr("Abrindo ", "Opening ") + app.label }

    view("https://www.google.com/search?q=" + enc(raw.trim()))
    return tr("Pesquisando no Google…", "Searching Google…")
}
