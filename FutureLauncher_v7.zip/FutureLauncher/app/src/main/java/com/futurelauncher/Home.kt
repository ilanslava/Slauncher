@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.futurelauncher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

private const val RS = "\u001E"
private const val FS = "\u001F"

fun SharedPreferences.list(key: String, seed: List<Pair<String, String>>): List<Pair<String, String>> {
    val raw = getString(key, null) ?: return seed
    return raw.split(RS).filter { it.contains(FS) }.map { val p = it.split(FS, limit = 2); p[0] to p[1] }
}

fun SharedPreferences.saveList(key: String, l: List<Pair<String, String>>) {
    edit().putString(key, l.joinToString(RS) { it.first + FS + it.second }).apply()
}

fun seedLinks() = listOf(
    "YouTube" to "app:com.google.android.youtube", "WhatsApp" to "app:com.whatsapp", "Instagram" to "app:com.instagram.android",
    "ChatGPT" to "app:com.openai.chatgpt", "Claude" to "app:com.anthropic.claude", "Facebook" to "app:com.facebook.katana"
)

fun openLink(ctx: Context, url: String) {
    runCatching {
        if (url.startsWith("app:")) {
            val pkg = url.removePrefix("app:")
            ctx.startActivity(ctx.packageManager.getLaunchIntentForPackage(pkg) ?: Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
        } else ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}

fun igOpen(ctx: Context, uri: String) {
    val ok = runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage("com.instagram.android")) }.isSuccess
    if (!ok) openLink(ctx, "app:com.instagram.android")
}

fun liveLines(hour: Int, battery: Int, sales: Int): List<String> {
    val l = mutableListOf<String>()
    l += when (hour) {
        in 5..11 -> tr("Bom dia! ☀️ Bora fazer o dia render?", "Good morning! ☀️ Ready to make today count?")
        in 12..17 -> tr("Boa tarde! 🌤 Como estão as vendas?", "Good afternoon! 🌤 How are sales going?")
        in 18..22 -> tr("Boa noite! 🌙 Ainda dá pra fechar um cliente hoje.", "Good evening! 🌙 You can still land a customer today.")
        else -> tr("Ainda acordado? 🦉 Não esquece de descansar.", "Still up? 🦉 Don't forget to rest.")
    }
    if (battery in 1..20) l += tr("Bateria em $battery%… cadê o carregador? 🔋", "Battery at $battery%… where's the charger? 🔋")
    l += if (sales == 0) tr("Hoje o primeiro cliente chega. 💪", "Today the first customer shows up. 💪")
    else tr("$sales clientes pagantes! Bora pro próximo 🚀", "$sales paying customers! On to the next 🚀")
    l += tr("Dica: digite \"timer 33\" na barra lá em cima.", "Tip: type \"timer 33\" in the bar up top.")
    l += tr("Toque em mim pra falar com o Google 🎤", "Tap me to talk to Google 🎤")
    l += tr("Segure um app na gaveta pra favoritar ★", "Long-press an app in the drawer to favorite ★")
    return l
}

@Composable
fun LiveAssistant(theme: Theme, lines: List<String>, say: String, onTap: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    var shown by remember { mutableStateOf("") }
    var blink by remember { mutableStateOf(false) }
    var look by remember { mutableStateOf(0) }
    var bounce by remember { mutableStateOf(false) }
    LaunchedEffect(lines, say) {
        if (say.isNotEmpty()) { shown = ""; for (c in say) { shown += c; delay(20) }; return@LaunchedEffect }
        var i = 0
        while (true) { val l = lines[i % lines.size]; shown = ""; for (c in l) { shown += c; delay(30) }; delay(5500); i++ }
    }
    LaunchedEffect(Unit) { while (true) { delay((2500L..5000L).random()); blink = true; delay(140); blink = false } }
    LaunchedEffect(Unit) { while (true) { delay((1800L..3600L).random()); look = (-1..1).random() } }
    LaunchedEffect(bounce) { if (bounce) { delay(160); bounce = false } }
    val t = rememberInfiniteTransition(label = "orb")
    val breathe by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val lookX by animateFloatAsState(look * 3f, tween(350), label = "l")
    val squash by animateFloatAsState(if (bounce) 0.8f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "s")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(
            Modifier.size(64.dp)
                .pointerInput(Unit) { detectTapGestures { bounce = true; haptic.performHapticFeedback(HapticFeedbackType.LongPress); onTap() } }
                .graphicsLayer { scaleX = breathe * squash; scaleY = breathe * squash }
        ) {
            val c = Offset(size.width / 2, size.height / 2)
            drawCircle(Brush.radialGradient(listOf(theme.a.copy(alpha = 0.45f), Color.Transparent), c, size.width / 2), radius = size.width / 2, center = c)
            drawCircle(Brush.linearGradient(listOf(theme.a, theme.b)), radius = size.width * 0.30f, center = c)
            val eyeH = if (blink) 2.dp.toPx() else 11.dp.toPx()
            val ew = 6.dp.toPx()
            for (dx in listOf(-8f, 8f)) {
                val cx = c.x + dx.dp.toPx() + lookX.dp.toPx()
                drawOval(Color.White, Offset(cx - ew / 2, c.y - eyeH / 2), Size(ew, eyeH))
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(shown, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f).glass(RoundedCornerShape(20.dp), theme.a).padding(horizontal = 14.dp, vertical = 10.dp))
    }
}

fun seedReplies() = listOf(
    tr("Saudação", "Greeting") to tr("Oi! Obrigado pelo interesse 🙌 Como posso te ajudar?", "Hi! Thanks for your interest 🙌 How can I help you?"),
    tr("Pagamento", "Payment") to tr("Segue o link seguro de pagamento: ", "Here's the secure payment link: "),
    tr("Código perdido", "Lost code") to tr("Sem problema! Me manda o e-mail da compra que eu te envio um código novo.", "No worries! Send me the purchase email and I'll send you a new code.")
)

fun group(c: Int) = when (c) {
    ApplicationInfo.CATEGORY_SOCIAL -> 1
    ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> 2
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> 3
    ApplicationInfo.CATEGORY_GAME -> 4
    else -> 0
}

fun groupName(g: Int) = when (g) { 1 -> "Social"; 2 -> tr("Mídia", "Media"); 3 -> tr("Trabalho", "Work"); else -> tr("Jogos", "Games") }

fun letterOf(s: String): Char = s.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#'

@Composable
fun Opt(label: String, onClick: () -> Unit) {
    Text(label, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp))
}

@Composable
fun SectionLabel(t: String) {
    Text(t, fontSize = 12.sp, color = Color.White.copy(alpha = 0.55f), modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 6.dp))
}

@Composable
fun TabChip(t: String, on: Boolean, accent: Color, onClick: () -> Unit) {
    Text(
        t, color = if (on) Color.Black else Color.White, fontSize = 13.sp,
        modifier = Modifier.clip(CircleShape).background(if (on) accent else Color.White.copy(alpha = 0.10f)).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun RoundBtn(t: String, accent: Color, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).glass(CircleShape, accent).clickable { onClick() }, contentAlignment = Alignment.Center) { Text(t, fontSize = 20.sp, color = Color.White) }
}

@Composable
fun ClockText(now: LocalDateTime, theme: Theme, size: Int) {
    Text(
        now.format(DateTimeFormatter.ofPattern("HH:mm")),
        style = TextStyle(brush = Brush.linearGradient(listOf(Color.White, theme.a, theme.b)), fontSize = size.sp, fontWeight = FontWeight.Thin)
    )
}

@Composable
fun AddDialog(title: String, l1: String, l2: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(a, { a = it }, label = { Text(l1) }, singleLine = true)
                OutlinedTextField(b, { b = it }, label = { Text(l2) })
            }
        },
        confirmButton = { TextButton(onClick = { if (a.isNotBlank() && b.isNotBlank()) onSave(a.trim(), b.trim()) }) { Text(tr("Salvar", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancelar", "Cancel")) } }
    )
}

@Composable
fun Hub(prefs: SharedPreferences, theme: Theme, now: LocalDateTime, date: String, apps: List<AppInfo>) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val accent = theme.a
    var links by remember { mutableStateOf(prefs.list("links", seedLinks())) }
    var replies by remember { mutableStateOf(prefs.list("replies", seedReplies())) }
    var sales by remember { mutableStateOf(prefs.getInt("sales", 0)) }
    var add by remember { mutableStateOf("") }
    var delLink by remember { mutableStateOf(-1) }
    var replyMenu by remember { mutableStateOf(-1) }
    val tile = RoundedCornerShape(20.dp)

    Row(verticalAlignment = Alignment.Bottom) {
        ClockText(now, theme, 60)
        Spacer(Modifier.width(12.dp))
        Text(date, fontSize = 15.sp, color = accent, modifier = Modifier.padding(bottom = 10.dp))
    }

    SectionLabel(tr("Atalhos", "Shortcuts"))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        links.forEachIndexed { i, (name, url) ->
            Column(
                Modifier.size(78.dp, 72.dp).glass(tile, accent).combinedClickable(
                    onClick = { openLink(ctx, url) },
                    onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); delLink = i }
                ),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                val ic = apps.firstOrNull { "app:" + it.pkg == url }?.icon
                if (ic != null) Image(ic, name, Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)))
                else Text(name.take(1).uppercase(), fontSize = 22.sp, color = accent, fontWeight = FontWeight.Medium)
                Text(name, fontSize = 11.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
        Box(Modifier.size(78.dp, 72.dp).glass(tile, accent).clickable { add = "link" }, contentAlignment = Alignment.Center) { Text("+", fontSize = 26.sp, color = accent) }
    }

    SectionLabel(tr("Enviar pro Instagram", "Post to Instagram"))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("📸 Story" to "instagram://story-camera", "🎬 Reels" to "instagram://reels-camera", "🖼 Post" to "instagram://library").forEach { (l, u) ->
            Text(l, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f).glass(CircleShape, accent).clickable { igOpen(ctx, u) }.padding(vertical = 11.dp))
        }
    }

    SectionLabel(tr("Respostas rápidas", "Quick replies"))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        replies.forEachIndexed { i, (label, text) ->
            Text(
                label, color = Color.White, fontSize = 13.sp,
                modifier = Modifier.glass(CircleShape, accent).combinedClickable(
                    onClick = { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null)) },
                    onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); replyMenu = i }
                ).padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
        Text("+", color = accent, fontSize = 18.sp, modifier = Modifier.glass(CircleShape, accent).clickable { add = "reply" }.padding(horizontal = 16.dp, vertical = 6.dp))
    }

    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp), accent).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text(tr("Clientes pagantes", "Paying customers"), fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
            Text("$sales", fontSize = 34.sp, color = accent, fontWeight = FontWeight.Light)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RoundBtn("−", accent) { if (sales > 0) { sales--; prefs.edit().putInt("sales", sales).apply() } }
            RoundBtn("+", accent) { sales++; prefs.edit().putInt("sales", sales).apply(); haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
            Text(
                "⏱ 33′", color = Color.White, fontSize = 14.sp,
                modifier = Modifier.glass(CircleShape, accent).clickable {
                    runCatching {
                        ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, 1980).putExtra(AlarmClock.EXTRA_MESSAGE, "33").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                        Toast.makeText(ctx, tr("Timer de 33 min iniciado", "33 min timer started"), Toast.LENGTH_SHORT).show()
                    }
                }.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }

    if (add == "link") AddDialog(tr("Novo atalho", "New shortcut"), tr("Nome", "Name"), tr("Link, número ou e-mail", "Link, number or email"), { add = "" }) { n, u ->
        val url = when {
            u.contains(":") -> u
            u.all { it.isDigit() || it in "+ -()" } -> "https://wa.me/" + u.filter { it.isDigit() }
            u.contains("@") -> "mailto:$u"
            else -> "https://$u"
        }
        links = links + (n to url); prefs.saveList("links", links); add = ""
    }
    if (add == "reply") AddDialog(tr("Nova resposta", "New reply"), tr("Título", "Title"), tr("Mensagem", "Message"), { add = "" }) { n, t ->
        replies = replies + (n to t); prefs.saveList("replies", replies); add = ""
    }
    if (delLink >= 0 && delLink < links.size) AlertDialog(
        onDismissRequest = { delLink = -1 }, title = { Text(links[delLink].first) },
        confirmButton = { TextButton(onClick = { links = links.filterIndexed { i, _ -> i != delLink }; prefs.saveList("links", links); delLink = -1 }) { Text(tr("Remover", "Remove")) } },
        dismissButton = { TextButton(onClick = { delLink = -1 }) { Text(tr("Cancelar", "Cancel")) } }
    )
    if (replyMenu >= 0 && replyMenu < replies.size) AlertDialog(
        onDismissRequest = { replyMenu = -1 }, title = { Text(replies[replyMenu].first) }, confirmButton = {},
        text = {
            Column {
                Opt(tr("Copiar", "Copy")) {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("reply", replies[replyMenu].second))
                    Toast.makeText(ctx, tr("Copiado", "Copied"), Toast.LENGTH_SHORT).show(); replyMenu = -1
                }
                Opt(tr("Remover", "Remove")) { replies = replies.filterIndexed { i, _ -> i != replyMenu }; prefs.saveList("replies", replies); replyMenu = -1 }
            }
        }
    )
}

@Composable
fun HomePage(
    dockApps: List<AppInfo>, top: List<AppInfo>, shape: IconShape, size: Float, duo: Boolean, theme: Theme, count: Int,
    layout: Int, prefs: SharedPreferences, apps: List<AppInfo>,
    openDrawer: () -> Unit, openSettings: () -> Unit, openAssistant: () -> Unit, onCommand: (String) -> String,
    launch: (AppInfo) -> Unit, onLong: (AppInfo) -> Unit
) {
    val ctx = LocalContext.current
    val accent = theme.a
    val now by produceState(LocalDateTime.now()) { while (true) { value = LocalDateTime.now(); delay(1000) } }
    val battery by produceState(0) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        while (true) { value = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); delay(30000) }
    }
    var cmd by remember { mutableStateOf("") }
    var fb by remember { mutableStateOf("") }
    LaunchedEffect(fb) { if (fb.isNotEmpty()) { delay(5000); fb = "" } }
    val date = now.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale.getDefault())).replaceFirstChar { it.uppercase() }
    val lines = remember(now.hour, battery / 10, now.minute / 10) { liveLines(now.hour, battery, prefs.getInt("sales", 0)) }
    val greeting = when (now.hour) { in 5..11 -> tr("Bom dia", "Good morning"); in 12..17 -> tr("Boa tarde", "Good afternoon"); else -> tr("Boa noite", "Good evening") }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).glass(RoundedCornerShape(28.dp), accent).padding(horizontal = 18.dp, vertical = 14.dp)) {
                if (cmd.isEmpty()) Text(tr("Digite um comando… (ex.: alarme 7:30)", "Type a command… (e.g. alarm 7:30 am)"), color = Color.White.copy(alpha = 0.5f), fontSize = 15.sp)
                BasicTextField(
                    value = cmd, onValueChange = { cmd = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp), cursorBrush = SolidColor(accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { fb = onCommand(cmd); cmd = "" }),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Text("🎤", fontSize = 22.sp, modifier = Modifier.clickable { openAssistant() }.padding(10.dp))
            Text("⚙", fontSize = 24.sp, color = Color.White.copy(alpha = 0.8f), modifier = Modifier.clickable { openSettings() }.padding(12.dp))
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        LiveAssistant(theme, lines, fb, openAssistant)
        Spacer(Modifier.height(10.dp))
        when (layout) {
            0 -> {
                Spacer(Modifier.height(40.dp))
                ClockText(now, theme, 110)
                Text(date, fontSize = 18.sp, color = accent)
            }
            2 -> Hub(prefs, theme, now, date, apps)
            else -> {
                ClockText(now, theme, 96)
                Text(date, fontSize = 18.sp, color = accent)
                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp), accent).padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(greeting, fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Medium)
                        Text(tr("$count apps instalados", "$count apps installed"), fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
                    }
                    Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val w = 7.dp.toPx()
                            val tl = Offset(w, w)
                            val sz = Size(this.size.width - 2 * w, this.size.height - 2 * w)
                            drawArc(color = Color.White.copy(alpha = 0.12f), startAngle = -90f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
                            drawArc(brush = Brush.sweepGradient(listOf(theme.a, theme.b, theme.a)), startAngle = -90f, sweepAngle = 360f * battery / 100f, useCenter = false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
                        }
                        Text("$battery%", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Medium)
                    }
                }
                if (top.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    SectionLabel(tr("Mais usados", "Most used"))
                    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp), accent).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        top.forEach { AppIcon(it, shape, (size * 0.85f).dp, theme, duo, true, { launch(it) }, { onLong(it) }) }
                    }
                }
            }
        }
        }
        Text(tr("⌃  deslize para ver os apps", "⌃  swipe up for apps"), color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).clickable { openDrawer() }.padding(8.dp))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(34.dp), accent).padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            dockApps.forEach { AppIcon(it, shape, size.dp, theme, duo, false, { launch(it) }, { onLong(it) }) }
        }
    }
}

@Composable
fun DrawerPage(
    apps: List<AppInfo>, shape: IconShape, size: Float, duo: Boolean, theme: Theme,
    prefs: SharedPreferences, favs: Set<String>, launch: (AppInfo) -> Unit, onLong: (AppInfo) -> Unit
) {
    val accent = theme.a
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var view by remember { mutableStateOf(prefs.getInt("dview", 0)) }
    val groups = remember(apps) { (1..4).filter { g -> apps.any { group(it.cat) == g } } }
    val list = remember(apps, query, tab, favs) {
        apps.filter { a -> a.label.contains(query, true) && when (tab) { 0 -> true; -1 -> a.pkg in favs; else -> group(a.cat) == tab } }
    }
    val letters = remember(list) { list.map { letterOf(it.label) }.distinct() }
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    var barH by remember { mutableStateOf(1f) }
    var active by remember { mutableStateOf<Char?>(null) }
    val s = shape.toShape()

    fun jump(y: Float) {
        if (letters.isEmpty()) return
        val c = letters[(y / barH * letters.size).toInt().coerceIn(0, letters.size - 1)]
        if (c != active) {
            active = c
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            val idx = list.indexOfFirst { letterOf(it.label) == c }.coerceAtLeast(0)
            scope.launch { if (view == 0) gridState.scrollToItem(idx) else listState.scrollToItem(idx) }
        }
    }

    Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 6.dp)) {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text(tr("Buscar app…", "Search apps…"), color = Color.White.copy(alpha = 0.4f)) },
                    shape = RoundedCornerShape(28.dp), modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let { launch(it) } }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = accent, unfocusedBorderColor = accent.copy(alpha = 0.4f), cursorColor = accent,
                        focusedContainerColor = Color.Black.copy(alpha = 0.3f), unfocusedContainerColor = Color.Black.copy(alpha = 0.3f)
                    )
                )
                Text(if (view == 0) "☰" else "▦", fontSize = 22.sp, color = accent, modifier = Modifier.clickable { view = 1 - view; prefs.edit().putInt("dview", view).apply() }.padding(12.dp))
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TabChip(tr("Todos", "All"), tab == 0, accent) { tab = 0 }
                TabChip("★", tab == -1, accent) { tab = -1 }
                groups.forEach { g -> TabChip(groupName(g), tab == g, accent) { tab = g } }
            }
            if (list.isEmpty()) {
                Text(
                    if (tab == -1) tr("Segure um app e escolha ★ Favoritar", "Long-press an app and choose ★ Favorite") else tr("Nenhum app encontrado", "No apps found"),
                    color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(20.dp)
                )
            } else if (view == 0) {
                LazyVerticalGrid(GridCells.Adaptive(size.dp + 28.dp), Modifier.fillMaxSize(), state = gridState, contentPadding = PaddingValues(end = 22.dp)) {
                    gridItems(list, key = { it.pkg }) { app -> AppIcon(app, shape, size.dp, theme, duo, true, { launch(app) }, { onLong(app) }) }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(end = 22.dp)) {
                    items(list, key = { it.pkg }) { app ->
                        Row(
                            Modifier.fillMaxWidth().combinedClickable(onClick = { launch(app) }, onLongClick = { onLong(app) }).padding(vertical = 7.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                bitmap = app.icon, contentDescription = app.label,
                                modifier = Modifier.size(46.dp).clip(s).background(Color.White.copy(alpha = 0.08f))
                                    .then(if (duo) Modifier.duotone(theme.a, theme.b) else Modifier)
                                    .border(1.dp, accent.copy(alpha = 0.45f), s)
                            )
                            Spacer(Modifier.width(16.dp))
                            Text(app.label, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                            if (app.pkg in favs) Text("★", color = accent, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
        if (letters.size > 1) {
            Column(
                Modifier.align(Alignment.CenterEnd).fillMaxHeight(0.7f).width(22.dp).onSizeChanged { barH = it.height.toFloat() }
                    .pointerInput(letters) { detectTapGestures(onTap = { jump(it.y); scope.launch { delay(400); active = null } }) }
                    .pointerInput(letters) { detectDragGestures(onDragStart = { jump(it.y) }, onDragEnd = { active = null }, onDragCancel = { active = null }) { change, _ -> jump(change.position.y) } },
                verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                letters.forEach { Text(it.toString(), fontSize = 10.sp, color = if (it == active) accent else Color.White.copy(alpha = 0.6f)) }
            }
        }
        active?.let {
            Box(Modifier.align(Alignment.Center).size(96.dp).glass(RoundedCornerShape(28.dp), accent), contentAlignment = Alignment.Center) {
                Text(it.toString(), fontSize = 52.sp, color = accent)
            }
        }
    }
}
